/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotel.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.hotel.model.Booking;
import com.hotel.utils.DatabaseConnection;

public class BookingDAO {
    public List<Booking> getAllBookings() {
        List<Booking> bookings = new ArrayList<>();
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM bookings")) {

            while (rs.next()) {
                bookings.add(new Booking(rs.getInt("id"), rs.getInt("customer_id"), rs.getInt("room_id"),
                        rs.getString("check_in"), rs.getString("check_out")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookings;
    }

    public boolean addBooking(Booking booking) {
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("INSERT INTO bookings (customer_id, room_id, check_in, check_out) VALUES (?, ?, ?, ?)")) {

            ps.setInt(1, booking.getCustomerId());
            ps.setInt(2, booking.getRoomId());
            ps.setString(3, booking.getCheckIn());
            ps.setString(4, booking.getCheckOut());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateBooking(Booking booking) {
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE bookings SET customer_id=?, room_id=?, check_in=?, check_out=? WHERE id=?")) {

            ps.setInt(1, booking.getCustomerId());
            ps.setInt(2, booking.getRoomId());
            ps.setString(3, booking.getCheckIn());
            ps.setString(4, booking.getCheckOut());
            ps.setInt(5, booking.getId());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteBooking(int id) {
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM bookings WHERE id=?")) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}

