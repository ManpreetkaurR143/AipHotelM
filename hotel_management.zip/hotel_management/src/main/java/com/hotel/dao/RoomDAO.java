/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotel.dao;

//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//import com.hotel.model.Room;
//import com.hotel.utils.DatabaseConnection;

public class RoomDAO {
//    public List<Room> getAllRooms() {
//        List<Room> rooms = new ArrayList<>();
//        try (Connection con = DatabaseConnection.getConnection();
//             Statement stmt = con.createStatement();
//             ResultSet rs = stmt.executeQuery("SELECT * FROM rooms")) {
//
//            while (rs.next()) {
//                rooms.add(new Room(rs.getInt("id"), rs.getString("room_number"), rs.getString("type"), rs.getString("price"), rs.getString("status")));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return rooms;
//    }
//
//    public boolean addRoom(Room room) {
//        try (Connection con = DatabaseConnection.getConnection();
//             PreparedStatement ps = con.prepareStatement("INSERT INTO rooms (room_number, type, price, status) VALUES (?, ?, ?, ?)")) {
//
//            ps.setString(1, room.getNumber());
//            ps.setString(2, room.getType());
//            ps.setDouble(3, room.getPrice());
//            ps.setBoolean(4, room.isStatus());
//
//            return ps.executeUpdate() > 0;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
//
//    public boolean updateRoom(Room room) {
//        try (Connection con = DatabaseConnection.getConnection();
//             PreparedStatement ps = con.prepareStatement("UPDATE rooms SET room_number=?, type=?, price=?, status=? WHERE id=?")) {
//
//            ps.setString(1, room.getNumber());
//            ps.setString(2, room.getType());
//            ps.setDouble(3, room.getPrice());
//            ps.setBoolean(4, room.isStatus());
//            ps.setInt(5, room.getId());
//
//            return ps.executeUpdate() > 0;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
//
//    public boolean deleteRoom(int id) {
//        try (Connection con = DatabaseConnection.getConnection();
//             PreparedStatement ps = con.prepareStatement("DELETE FROM rooms WHERE id=?")) {
//
//            ps.setInt(1, id);
//            return ps.executeUpdate() > 0;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
}

