/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotel.api;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.hotel.model.Booking;
import com.hotel.utils.DatabaseConnection;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/api/booking")
public class BookingAPI extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Booking> bookings = new ArrayList<>();
        try {
            Connection con = DatabaseConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM bookings");

            while (rs.next()) {
                Booking booking = new Booking(
                        rs.getInt("id"),
                        rs.getInt("customer_id"),  // Adjusted field name
                        rs.getInt("room_id"),
                        rs.getString("check_in"),
                        rs.getString("check_out")
                );
                bookings.add(booking);
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            try (PrintWriter writer = response.getWriter()) {
                writer.write(gson.toJson(bookings));
            }
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error occurred");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String id = request.getParameter("id");
        String customerId = request.getParameter("customerId"); // Adjusted field name
        String roomId = request.getParameter("roomId");
        String checkIn = request.getParameter("checkIn");
        String checkOut = request.getParameter("checkOut");
        String action = request.getParameter("action");

        if (("update".equals(action) || "add".equals(action)) && (customerId == null || roomId == null || checkIn == null || checkOut == null)) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing parameters\"}");
            return;
        }

        switch (action) {
            case "update":
                if (id == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing id parameter\"}");
                    return;
                }
                try (Connection con = DatabaseConnection.getConnection(); PreparedStatement ps = con.prepareStatement("UPDATE bookings SET customer_id=?, room_id=?, check_in=?, check_out=? WHERE id=?")) {

                    ps.setInt(1, Integer.parseInt(customerId));
                    ps.setInt(2, Integer.parseInt(roomId));
                    ps.setString(3, checkIn);
                    ps.setString(4, checkOut);
                    ps.setInt(5, Integer.parseInt(id));

                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_OK : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
            case "delete":
                if (id == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing id parameter\"}");
                    return;
                }
                try (Connection con = DatabaseConnection.getConnection(); PreparedStatement ps = con.prepareStatement("DELETE FROM bookings WHERE id=?")) {

                    ps.setInt(1, Integer.parseInt(id));
                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_OK : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
            default:
                try (Connection con = DatabaseConnection.getConnection(); PreparedStatement ps = con.prepareStatement("INSERT INTO bookings (customer_id, room_id, check_in, check_out) VALUES (?, ?, ?, ?)")) {

                    ps.setInt(1, Integer.parseInt(customerId)); // Adjusted field name
                    ps.setInt(2, Integer.parseInt(roomId));
                    ps.setString(3, checkIn);
                    ps.setString(4, checkOut);

                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_CREATED : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
        }
    }
}
