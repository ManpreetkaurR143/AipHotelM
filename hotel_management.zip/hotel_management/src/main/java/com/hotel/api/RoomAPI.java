/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hotel.api;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.hotel.model.Room;
import com.google.gson.Gson;
import com.hotel.utils.DatabaseConnection;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/api/room")
public class RoomAPI extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Room> rooms = new ArrayList<>();
        try {
            Connection con = DatabaseConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM rooms");

            while (rs.next()) {
                Room room = new Room(
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("type"),
                        rs.getString("price"),
                        rs.getString("status")
                );
                rooms.add(room);
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            try (PrintWriter writer = response.getWriter()) {
                writer.write(gson.toJson(rooms));  // Convert list to JSON
            }
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error occurred");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String id = request.getParameter("id");
        String room_number = request.getParameter("number");
        String type = request.getParameter("type");
        String price = request.getParameter("price");
        String status = request.getParameter("status");
        String action = request.getParameter("action");

        if (("update".equals(action) || "add".equals(action)) && (room_number == null || type == null || price == null || status == null || action == null)) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing parameters\"}");
            return;
        }

        switch (action) {
            case "update":
                if (id == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing id parameters\"}");
                    return;
                }
                try (Connection con = DatabaseConnection.getConnection(); PreparedStatement ps = con.prepareStatement("UPDATE rooms SET room_number=?, type=?, price=?, status=? WHERE id=?")) {

                    ps.setString(1, room_number);
                    ps.setString(2, type);
                    ps.setString(3, price);
                    ps.setString(4, status);
                    ps.setInt(5, Integer.parseInt(id));

                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_OK : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
            case "delete":
                if (id == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Missing id parameters\"}");
                    return;
                }
                try {
                    Connection con = DatabaseConnection.getConnection();
                    PreparedStatement ps = con.prepareStatement("DELETE FROM rooms WHERE id=?"); 

                    ps.setInt(1, Integer.parseInt(id));
                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_CREATED : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
            default:
                try (Connection con = DatabaseConnection.getConnection(); PreparedStatement ps = con.prepareStatement("INSERT INTO rooms (room_number, type, price, status) VALUES (?, ?, ?, ?)")) {

                    ps.setString(1, room_number);
                    ps.setString(2, type);
                    ps.setString(3, price);
                    ps.setString(4, status);

                    boolean success = ps.executeUpdate() > 0;

                    response.setStatus(success ? HttpServletResponse.SC_CREATED : HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter writer = response.getWriter();
                    writer.write("{\"status\": \"" + (success ? "success" : "error") + "\"}");
                    writer.close();
                } catch (Exception e) {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\": \"error\", \"message\": \"Database error\"}");
                }
                break;
        }
    }

}
